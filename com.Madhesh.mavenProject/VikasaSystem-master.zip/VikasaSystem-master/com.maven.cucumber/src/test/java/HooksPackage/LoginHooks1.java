package HooksPackage;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class LoginHooks1 {

	/*@Before(order = 1)
	public static void beforeMethod() {

		System.out.println("Launch the Browser");

	}
                                                       //Before "Order" Should be ascending order
	@After(order = 1)                                  //After  "Order" Should be descending order 
	public static void AfterMethod() {

		System.out.println("Close the browser");
	}

	@Before(order = 0)
	public static void beforeMethod1() {

		System.out.println("Check the Internet Connection");

	}

	@After(order =0)
	public static void AfterMethod1() {

		System.out.println("Close The Eclipse");
	}*/
}