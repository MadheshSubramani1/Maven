package HooksPackage;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TaggedHooks {
/*
	@Before
	public void beforeEveryScenario() {

		System.out.println("This will run Before Every Scenario");
}

	@After
	public void afterEveryScenario() {

		System.out.println("This will run After Every Scenario");
	}

	@Before("@FirstScenario")
	public void beforeFirstScenario() {

		System.out.println("This will run Before First Scenario");

	}

	@After("@FirstScenario")
	public void afterFirstScenario() {

		System.out.println("This will run After first Scenario");
	}

	@Before("@SecondScenario")
	public void beforeSecondScenario() {

		System.out.println("This will run Before Second Scenario");

	}

	@After("@SecondScenario")
	public void afterSecondScenario() {

		System.out.println("This will run After Second Scenario");
	}

	@Before("@ThirdScenario")
	public void beforeThirdScenario() {

		System.out.println("This will run Before Third Scenario");

	}

	@After("@ThirdScenario")
	public void afterThirdScenario() {

		System.out.println("This will run After Third Scenario");
	}*/

}
