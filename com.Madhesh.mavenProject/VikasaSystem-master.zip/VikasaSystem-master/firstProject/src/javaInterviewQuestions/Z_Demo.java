package javaInterviewQuestions;

public class Z_Demo {

	public static void main(String[] args) {

		
		System.out.println("HI Madhesh");
		System.out.println("Are You Automation Engineer?");

	}
}