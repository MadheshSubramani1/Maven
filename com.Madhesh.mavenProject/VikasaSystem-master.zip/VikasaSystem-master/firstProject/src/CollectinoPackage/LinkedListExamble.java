package CollectinoPackage;

import java.util.LinkedList;
import java.util.Stack;
import java.util.Vector;

public class LinkedListExamble {

	public static void main(String[] args) {
	
	Vector<String> ve=new Vector<String>();
	
	ve.addElement("dsf");
	ve.addElement("dsf123");
	ve.addElement("dsf123adasd");
	System.out.println(ve);
	
	ve.removeElement("dsf123");
	System.out.println(ve);
	}

}
